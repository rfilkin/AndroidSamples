package rFilkin.com;

public class CarInformation {
    private String model;
    private String manufacturer;
    private String color;
    private String price;
    private String type;
    private int pict_id;

    public static String MODEL = "model";
    public static String MANUFACTURE = "manufacturer";
    public static String COLOR = "color";
    public static String PRICE = "price";
    public static String TYPE = "type";
    public static String IMAGE = "image";

    public CarInformation(String model, String manufacturer, String color, String type, String price, int pict_id){
        this.model = model;
        this.manufacturer = manufacturer;
        this.color = color;
        this.price = price;
        this.type = type;
        this.pict_id = pict_id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPict_id() {
        return pict_id;
    }

    public void setPict_id(int pict_id) {
        this.pict_id = pict_id;
    }

    @Override
    public String toString(){
        return "Model: " + model +
                "\nManufacturer: " + manufacturer +
                "\nColor: " + color +
                "\nPrice: " + price +
                "\nType: " + type +
                "\nPicture ID: " + pict_id;
    }




}
