package rFilkin.com;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;

public class CarRecyclerViewAdapter extends RecyclerView.Adapter<CarRecyclerViewAdapter.ViewHolder>{

    public ArrayList<Integer> pictureIds = new ArrayList<>();
    private final OnAdapterItemInteraction mListener;
    public CarRecyclerViewAdapter(ArrayList<Integer> pictureIds,
                                  OnAdapterItemInteraction listener) {
        this.pictureIds = pictureIds;
        mListener = listener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final ImageView carImageView;
        public ViewHolder(View view) {
            super(view);
            mView = view;
            carImageView = (ImageView)view.findViewById(R.id.carImageIcon);
        }
    }

    public interface OnAdapterItemInteraction {
        void onItemSelected(ViewHolder holder, Integer position);
    }

    @Override
    public CarRecyclerViewAdapter.ViewHolder
    onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.car_row_cardview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            final CarRecyclerViewAdapter.ViewHolder holder, final int position) {
        holder.carImageView.setImageResource(pictureIds.get(position));
        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onItemSelected(holder, position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return pictureIds.size();
    }
}
