package rFilkin.com;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * A placeholder fragment containing a simple view.
 */
public class CarDetailsFragment extends Fragment {

    public CarDetailsFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_car_details, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        TextView tvManufacturer = getActivity().
                findViewById(R.id.carDetails_Manufacturer);
        TextView tvModel = getActivity().findViewById(R.id.carDetails_Model);
        TextView tvColor = getActivity().findViewById(R.id.carDetails_Color);
        TextView tvType = getActivity().findViewById(R.id.carDetails_Type);
        TextView tvPrice = getActivity().findViewById(R.id.carDetails_Price);
        ImageView ivImage = getActivity().findViewById(R.id.carDetails_CarImage);

        Intent intent = getActivity().getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null){
            String manufacturer = (String) bundle.get(CarInformation.MANUFACTURE);
            tvManufacturer.setText(!TextUtils.isEmpty(manufacturer)?
                    manufacturer:"Unknown");
            String model = (String) bundle.get(CarInformation.MODEL);
            tvModel.setText(!TextUtils.isEmpty(manufacturer)?model:"Unknown");
            String color = (String) bundle.get(CarInformation.COLOR);
            tvColor.setText(!TextUtils.isEmpty(color)?color:"Unknown");
            String price = (String) bundle.get(CarInformation.PRICE);
            tvPrice.setText(!TextUtils.isEmpty(price)?price:" 0");
            String type = (String) bundle.get(CarInformation.TYPE);
            tvType.setText(!TextUtils.isEmpty(type)?type:"Unknown");
            int icon_id = (int)bundle.getInt(CarInformation.IMAGE, -1);
            if (icon_id > -1){
                // Set the drawable as the content of the imageView
                ivImage.setImageResource(icon_id);
                ivImage.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                //ivImage.setBackgroundResource(defaultItemBackground); //default item background
            }


            Button b = getActivity().findViewById(R.id.btnReturnToMain);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getActivity().supportFinishAfterTransition();
            }
        });
    }

}
}
