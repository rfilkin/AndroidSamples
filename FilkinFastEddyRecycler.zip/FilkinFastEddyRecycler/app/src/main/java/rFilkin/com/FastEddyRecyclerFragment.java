package rFilkin.com;

import android.content.Intent;
import android.os.Build;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view.
 */
public class FastEddyRecyclerFragment extends Fragment implements CarRecyclerViewAdapter.OnAdapterItemInteraction {

    private static final String TAG = "FastEddyRecyclerFragmen";
    CarRecyclerViewAdapter carAdapter = null;
    ArrayList<CarInformation> mCarLotData = null;
    ArrayList<Integer> pictureIds = new ArrayList<Integer>();

    public FastEddyRecyclerFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fast_eddy_recycler, container, false);
    }

    @Override
    public void onItemSelected(CarRecyclerViewAdapter.ViewHolder holder, Integer
            position)
    {
        showDetails(holder,position);
    }

    private void showDetails(CarRecyclerViewAdapter.ViewHolder holder, int position){
        Intent intent = new Intent(getActivity(), CarDetails.class);
        intent.putExtra(CarInformation.MODEL, mCarLotData.get(position).getModel());
        intent.putExtra(CarInformation.MANUFACTURE,
                mCarLotData.get(position).getManufacturer());
        intent.putExtra(CarInformation.COLOR, mCarLotData.get(position).getColor());
        intent.putExtra(CarInformation.PRICE, mCarLotData.get(position).getPrice());
        intent.putExtra(CarInformation.TYPE, mCarLotData.get(position).getType());
        intent.putExtra(CarInformation.IMAGE, mCarLotData.get(position).getPict_id());
        View carImageView = holder.carImageView;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ActivityOptionsCompat options =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(getActivity(),
                            carImageView, carImageView.getTransitionName());
            getActivity().startActivity(intent, options.toBundle());
        } else {
            getActivity().startActivity(intent);
        }
    }

    private void setUpCarData() {
        CarLotData carLotData = new CarLotData();
        mCarLotData = carLotData.getCarLotInfo();
        for (CarInformation cld : mCarLotData) {
            pictureIds.add(cld. getPict_id ());
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.d(TAG, "onActivityCreated");
        setUpCarData();
        RecyclerView recyclerView=

                (RecyclerView)getActivity().findViewById(R.id.fastEddyRecyclerView);
        carAdapter = new CarRecyclerViewAdapter(pictureIds, this);
        recyclerView.setAdapter(carAdapter);
        final int spanCount = getResources().getInteger(R.integer.grid_columns);
        final GridLayoutManager layoutManager =
                new GridLayoutManager(getActivity(), spanCount);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
    }
}
