package rFilkin.com;

import java.util.ArrayList;

public class CarLotData {
    private ArrayList<CarInformation> mCarLotData = new ArrayList<>();
    CarLotData(){
        setUpData();
    }
    // Would be more likely to have a database here, for class purposes hardcoding data
    public void setUpData() {
        mCarLotData.add(new CarInformation("Sedan 1938","Chevrolet","Green","Sedan",
                "5000", R.drawable.chevrolet_sedan_1938));
        mCarLotData.add(new CarInformation("Red","Chevrolet","Red","Sedan",
                "8000", R.drawable.classic_car_red));
        mCarLotData.add(new CarInformation("Jaguar","Jaguar","Silver","Convertible",
                "13000", R.drawable.classic_jaguar));
        mCarLotData.add(new CarInformation("Grand Touring","Skoda","Silver","Sedan",
                "4000", R.drawable.greatcar));
        mCarLotData.add(new CarInformation("Van","Volkswagen","Orange","MiniVan",
                "2000", R.drawable.volkswagen_van));
        mCarLotData.add(new CarInformation("Civic","Honda","Blue","Sedan",
                "3000", R.drawable.car1));
        mCarLotData.add(new CarInformation("Cadillac","Cadillac","Silver","Sedan",
                "12000", R.drawable.car2));
        mCarLotData.add(new CarInformation("Mini","Cooper","Blue","Coupe",
                "8000", R.drawable.car3));
        mCarLotData.add(new CarInformation("Jeep","Chrysler","Green","Sedan",
                "5000", R.drawable.car4));
        mCarLotData.add(new CarInformation("Mustang","Ford","Red","Sedan",
                "20000", R.drawable.car5));
        mCarLotData.add(new CarInformation("SUV","Volkswagen","Gray","MiniVan",
                "7000", R.drawable.car6));
    }
    public ArrayList<CarInformation> getCarLotInfo() {
        return mCarLotData;
    }
}

