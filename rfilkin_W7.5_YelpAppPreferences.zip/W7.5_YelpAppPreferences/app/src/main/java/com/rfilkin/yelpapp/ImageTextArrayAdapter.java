package com.rfilkin.yelpapp;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ImageTextArrayAdapter extends ArrayAdapter<Restaurant> {
    public final static String TAG = "ImageTextArrayAdapter";
    int layoutResourceId;
    Context context;
    private List<Restaurant> data;
    private LayoutInflater inflater;

    public ImageTextArrayAdapter(Context context, int layoutResourceId, List<Restaurant> data) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        /*LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        Log.d(TAG, "getView: rowView null: position " + position);
        View rowView = inflater.inflate(layoutResourceId, parent, false);
        TextView restaurantNameView = rowView.findViewById(R.id.restaurant_name);
        TextView restaurantLocationView = rowView.findViewById(R.id.restaurant_location);
        TextView restaurantFoodtypeView = rowView.findViewById(R.id.restaurant_foodtype);
        TextView restaurantCostView = rowView.findViewById(R.id.restaurant_cost);
        ImageView restaurantLogoView = rowView.findViewById(R.id.restaurant_logo);
        restaurantNameView.setText(data.get(position). name);
        restaurantLocationView.setText(data.get(position). location);
        restaurantFoodtypeView.setText(data.get(position). foodtype);
        restaurantCostView.setText(data.get(position). cost);
        restaurantLogoView.setImageResource(data.get(position). logo);
        return rowView;
        */
        RestaurantHolder holder = null;
        if (null == convertView) {
            Log.d(TAG, "getView: rowView null: position make new holder" + position);
            convertView = inflater.inflate(layoutResourceId, parent, false);
            holder = new RestaurantHolder();
            holder.imgLogo = convertView.findViewById(R.id.restaurant_logo);
            holder.txtName = convertView.findViewById(R.id.restaurant_name);
            holder.txtLocation = convertView.findViewById(R.id.restaurant_location);
            holder.txtFoodtype = convertView.findViewById(R.id.restaurant_foodtype);
            holder.txtCost = convertView.findViewById(R.id.restaurant_cost);
            // Tags can be used to store data within a view
            convertView.setTag(holder);
        }
        else {
            Log.d(TAG, "getView: rowView !null - reuse holder: position " + position);
            holder = (RestaurantHolder)convertView.getTag();
        }
// Display the information for that item
        Restaurant restaurant = data.get(position);
        holder.txtName.setText(restaurant.name);
        holder.txtLocation.setText(restaurant.location);
        holder.txtFoodtype.setText(restaurant.foodtype);
        holder.txtCost.setText(restaurant.cost);
        holder.imgLogo.setImageResource(restaurant.logo);
        return convertView;
    }

    static class RestaurantHolder {
        ImageView imgLogo;
        TextView txtName;
        TextView txtLocation;
        TextView txtFoodtype;
        TextView txtCost;
    }
}
