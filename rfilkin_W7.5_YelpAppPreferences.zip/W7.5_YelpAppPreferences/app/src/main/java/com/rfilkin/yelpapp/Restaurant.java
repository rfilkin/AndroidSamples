package com.rfilkin.yelpapp;

public class Restaurant {
    public int logo;
    public String name;
    public String location;
    public String foodtype;
    public String cost;

    public Restaurant() {
        super();
    }
    public Restaurant(int logo, String name, String location, String foodtype, String cost) {
        super();
        this.logo = logo;
        this.name = name;
        this.location = location;
        this.foodtype = foodtype;
        this.cost = cost;
    }

}
