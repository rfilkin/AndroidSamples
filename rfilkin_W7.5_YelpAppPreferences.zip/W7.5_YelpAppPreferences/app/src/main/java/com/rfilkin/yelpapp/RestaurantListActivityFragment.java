package com.rfilkin.yelpapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class RestaurantListActivityFragment extends Fragment {
    public final static String TAG = "RestaurantListFragment";
    private final static String KEY_POSITION = "key_position";
    private final static String INITIAL_POSITION = "pref_position";

    private final static String SELECTED_SHOW_RESTAURANT_TYPE = "pref_selected_show";
    //private final static String WHATIF_BTN_PREF = "pref_display_button";

    public static final int SHOW_PREFERENCES = 1;

    ImageTextArrayAdapter adapter;

    private int mPosition;
    private List<Restaurant> restaurant_data ;


    public RestaurantListActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_restaurant_list, container, false);
    }

    private List <Restaurant> setupRestaurants() {
        String cost_1 = getResources().getString(R.string.cost_1).toString();
        String cost_2 = getResources().getString(R.string.cost_2).toString();
        String cost_3 = getResources().getString(R.string.cost_3).toString();
        String cost_4 = getResources().getString(R.string.cost_4).toString();
        List<Restaurant> restaurant_data_list ;
        Restaurant[] restaurants;

        SharedPreferences mySharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(getActivity());

        int showRestaurantTypeId = Integer.parseInt(mySharedPreferences.
                getString(SELECTED_SHOW_RESTAURANT_TYPE, "0"));

        switch(showRestaurantTypeId){
            case 1:
                restaurants = new Restaurant[] {
                        new Restaurant(R.drawable.monster_thai,"Monster Thai",
                                "12920 Riverside Dr\n" + "Sherman Oaks, CA 91423", "Thai", cost_1),
                        new Restaurant(R.drawable.noodle_world_jr,"Noodle World Jr",
                                "14622 Ventura Blvd\n" + "Los Angeles, CA 91403", "Noodles, Asian Fusion, Bubble Tea", cost_1)
                };
                break;
            case 2:
                restaurants = new Restaurant[] {
                        new Restaurant(R.drawable.midici,"MidiCi",
                                "14612 Ventura Blvd\n" + "Sherman Oaks, CA 91403", "Italian, Pizza", cost_2),
                        new Restaurant(R.drawable.umami_burger,"Umami Burger",
                                "189 The Grove Dr\n" + "Ste C-10\n" + "Los Angeles, CA 90036", "Burgers, American", cost_2)
                };
                break;
            case 3:
                restaurants = new Restaurant[] {
                        new Restaurant (R.drawable.mistral_logo, "Mistral",
                                "13422 Ventura Blvd\n" + "Sherman Oaks, CA 91423", "French", cost_3),
                        new Restaurant(R.drawable.giacomino_drago_black, "Panzanella Ristorante",
                                "14928 Ventura Blvd\n" + "Sherman Oaks, CA 91403", "Sicilian, Wine Bars", cost_3)
                };
                break;
            case 4:
                restaurants = new Restaurant[] {
                        new Restaurant(R.drawable.mastro_logo, "Mastro's Penthouse",
                                "246 N Canon Dr\n" + "Beverly Hills, CA 90210", "Steak", cost_4),
                        new Restaurant(R.drawable.sol_agave,"Sol Agave",
                                "27741 Crown Valley Pkwy\n" + "Unit 329\n" + "Mission Viejo, CA 92691", "Mexican", cost_4)
                };
                break;
            default:
                restaurants = new Restaurant[] {
                        new Restaurant(R.drawable.mastro_logo, "Mastro's Penthouse",
                                "246 N Canon Dr\n" + "Beverly Hills, CA 90210", "Steak", cost_4),
                        new Restaurant(R.drawable.midici,"MidiCi",
                                "14612 Ventura Blvd\n" + "Sherman Oaks, CA 91403", "Italian, Pizza", cost_2),
                        new Restaurant (R.drawable.mistral_logo, "Mistral",
                                "13422 Ventura Blvd\n" + "Sherman Oaks, CA 91423", "French", cost_3),
                        new Restaurant(R.drawable.monster_thai,"Monster Thai",
                                "12920 Riverside Dr\n" + "Sherman Oaks, CA 91423", "Thai", cost_1),
                        new Restaurant(R.drawable.noodle_world_jr,"Noodle World Jr",
                                "14622 Ventura Blvd\n" + "Los Angeles, CA 91403", "Noodles, Asian Fusion, Bubble Tea", cost_1),
                        new Restaurant(R.drawable.giacomino_drago_black, "Panzanella Ristorante",
                                "14928 Ventura Blvd\n" + "Sherman Oaks, CA 91403", "Sicilian, Wine Bars", cost_3),
                        new Restaurant(R.drawable.sol_agave,"Sol Agave",
                                "27741 Crown Valley Pkwy\n" + "Unit 329\n" + "Mission Viejo, CA 92691", "Mexican", cost_4),
                        new Restaurant(R.drawable.umami_burger,"Umami Burger",
                                "189 The Grove Dr\n" + "Ste C-10\n" + "Los Angeles, CA 90036", "Burgers, American", cost_2)
                };
                break;
        }
        // Convert array to List.
        restaurant_data_list= new ArrayList<>(Arrays.asList(restaurants));
        return restaurant_data_list;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        restaurant_data = setupRestaurants();
        ListView listView = getActivity().findViewById(R.id.restaurantList);

        adapter = new ImageTextArrayAdapter(getActivity(),
                R.layout.restaurant_item, restaurant_data);

        listView.setAdapter(adapter);

        SharedPreferences mySharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (savedInstanceState != null){
            mPosition = savedInstanceState.getInt(KEY_POSITION, 0);
            Log.d(TAG,"onActivityCreated savedInstanceState mPosition " + mPosition);
        } else {
            mPosition = mySharedPreferences.getInt(INITIAL_POSITION, 0);
            Log.d(TAG,"onActivityCreated mySharedPreferences mPosition " + mPosition);
        }

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        Log.d(TAG," RestaurantListActivityFragment onCreateOptionsMenu");
// Inflate the menu; this adds items to the app bar if it is present.
        //inflater.inflate(R.menu.restaurant_fragment_items, menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(TAG, "RestaurantListActivityFragment onOptionsItemSelected: " +
                Integer.toHexString(item.getItemId()));

        switch (item.getItemId()) {
            /*case R.id.whatIsIt:
                Log.d(TAG," PlanetListActivityFragment onOptionsItemSelected: whatIsIt ");
                //clickWhatIsItButton();
                return true;*/
            case R.id.action_settings:
                startActivityForResult(new Intent(getActivity(),
                        SettingsActivity.class),SHOW_PREFERENCES);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onDestroy()
    {
        savePrefs(INITIAL_POSITION, mPosition);
        super.onDestroy();
    }
    private void savePrefs(String key, int value) {
        SharedPreferences sp =
                PreferenceManager.getDefaultSharedPreferences(getActivity());
        SharedPreferences.Editor ed = sp.edit();
        ed.putInt(key, value);
        ed. apply ();
    }

    @Override
    public void onActivityResult(int reqCode, int resCode, Intent data) {
        super.onActivityResult(reqCode, resCode, data);
        Log.d(TAG," onActivityResult " + " data: " + data);
        switch(reqCode) {
            case SHOW_PREFERENCES:
                SharedPreferences mySharedPreferences =
                        PreferenceManager.getDefaultSharedPreferences(getActivity());
                // get value of pref controlling show/hide of whatIsButton
                //boolean showWhatIsButton = mySharedPreferences.getBoolean(WHATIF_BTN_PREF, true);
                //Log.d(TAG," onActivityResult " + " SHOW_PREFERENCES: mShowWhatIsButton " + showWhatIsButton);
                //flipWhatIfButton(showWhatIsButton);
// get planet data corresponding to preference (pref is in the setupPlanet method)
                restaurant_data = setupRestaurants();
                adapter.clear(); // Clear old data
                adapter.addAll(restaurant_data); // Add the new data
                adapter.notifyDataSetChanged(); // Notify adapter that the dataset changed
                break;
        }
    }

    public void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_POSITION, mPosition);
    }
}
